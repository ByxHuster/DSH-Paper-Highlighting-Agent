# Mock paper markdown (not used by normalize)

Body.
